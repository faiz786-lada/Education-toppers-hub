# Education Toppers Hub

A comprehensive educational platform for sharing posters, images, and videos.

## Features

### User Features
- 📱 Fully responsive design
- 🔍 Search and filter content
- 📤 Share content on social media
- 🌓 Dark/Light mode toggle
- 📊 Real-time content stats
- 🖼️ Lightbox image viewer
- 📱 Mobile-friendly interface

### Admin Features
- 🔐 Secure admin authentication
- 📤 Upload posters, images, and videos
- 🗑️ Delete content
- 📊 Dashboard with analytics
- 🎨 Customizable website settings
- 📈 Content management system

## Tech Stack

- **Frontend**: HTML5, CSS3, JavaScript (ES6+)
- **Backend**: Firebase Firestore
- **Storage**: Firebase Storage
- **Authentication**: Firebase Auth
- **Hosting**: Netlify

## Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/education-toppers-hub.git
