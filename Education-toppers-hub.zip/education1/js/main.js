import { 
    db, storage, auth,
    collection, getDocs, deleteDoc, doc,
    query, orderBy, serverTimestamp,
    ref, getDownloadURL, deleteObject,
    COLLECTIONS, STORAGE_PATHS
} from './firebase-config.js';
import { 
    escapeHtml, showNotification, showSkeletons, 
    getEmbedUrl, formatDate, getShareUrl,
    shareOnSocial, copyToClipboard, debounce
} from './utils.js';

// Global State
let posters = [];
let images = [];
let videos = [];
let currentFilter = 'all';
let searchQuery = '';

// DOM Elements
const postersGrid = document.getElementById('posters-grid');
const imagesGrid = document.getElementById('images-grid');
const videosGrid = document.getElementById('videos-grid');
const searchInput = document.getElementById('search-input');
const searchClear = document.getElementById('search-clear');
const categories = document.getElementById('categories');

// Load Header
async function loadHeader() {
    const headerHtml = `
        <div class="header-container">
            <a href="/" class="logo">
                <img src="/assets/images/logo.png" alt="Logo" onerror="this.src='https://via.placeholder.com/40'">
                Education <span>Toppers Hub</span>
            </a>
            
            <nav class="nav-menu" id="nav-menu">
                <a href="#home" class="nav-link">Home</a>
                <a href="#posters" class="nav-link">Posters</a>
                <a href="#images" class="nav-link">Gallery</a>
                <a href="#videos" class="nav-link">Videos</a>
                <a href="#contact" class="nav-link">Contact</a>
                <a href="/pages/admin.html" class="nav-link" id="admin-link">Admin</a>
            </nav>
            
            <div class="header-actions">
                <button class="search-toggle" id="search-toggle">
                    <i class="fas fa-search"></i>
                </button>
                <button class="theme-toggle" id="theme-toggle">
                    <i class="fas fa-moon"></i>
                </button>
                <div class="mobile-menu-btn" id="mobile-menu-btn">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
        </div>
    `;
    
    const header = document.getElementById('main-header');
    if (header) header.innerHTML = headerHtml;
}

// Load Stats
async function loadStats() {
    const statsHtml = `
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon blue">
                    <i class="fas fa-images"></i>
                </div>
                <div class="stat-value" id="posters-count">${posters.length}</div>
                <div class="stat-label">Posters</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon green">
                    <i class="fas fa-camera"></i>
                </div>
                <div class="stat-value" id="images-count">${images.length}</div>
                <div class="stat-label">Images</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon amber">
                    <i class="fas fa-video"></i>
                </div>
                <div class="stat-value" id="videos-count">${videos.length}</div>
                <div class="stat-label">Videos</div>
            </div>
        </div>
    `;
    
    const statsSection = document.getElementById('stats');
    if (statsSection) statsSection.innerHTML = statsHtml;
}

// Load Search & Filter
function loadSearchFilter() {
    const searchHtml = `
        <div class="search-container">
            <i class="fas fa-search search-icon"></i>
            <input type="search" class="search-input" id="search-input" 
                   placeholder="Search posters, images, videos..." autocomplete="off">
            <button class="search-clear" id="search-clear">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <div class="categories" id="categories">
            <button class="category-btn active" data-category="all">
                <i class="fas fa-border-all"></i> All
            </button>
            <button class="category-btn" data-category="poster">
                <i class="fas fa-image"></i> Posters
            </button>
            <button class="category-btn" data-category="image">
                <i class="fas fa-camera"></i> Images
            </button>
            <button class="category-btn" data-category="video">
                <i class="fas fa-play-circle"></i> Videos
            </button>
        </div>
    `;
    
    const searchFilter = document.getElementById('search-filter');
    if (searchFilter) searchFilter.innerHTML = searchHtml;
}

// Render Poster Card
function renderPosterCard(poster) {
    const shareUrl = getShareUrl(poster.id, 'poster');
    
    return `
        <div class="content-card" data-id="${poster.id}" data-type="poster">
            <div class="card-image">
                <img src="${escapeHtml(poster.imageUrl)}" alt="${escapeHtml(poster.title)}" loading="lazy">
                <button class="share-btn" data-share='${JSON.stringify({url: shareUrl, title: poster.title, type: 'poster', id: poster.id})}'>
                    <i class="fas fa-share-alt"></i>
                </button>
            </div>
            <div class="card-content">
                <h3 class="card-title">${escapeHtml(poster.title)}</h3>
                ${poster.description ? `<p class="card-description">${escapeHtml(poster.description)}</p>` : ''}
                <div class="card-meta">
                    <span><i class="far fa-calendar-alt"></i> ${formatDate(poster.timestamp)}</span>
                    <span><i class="fas fa-eye"></i> ${poster.views || 0} views</span>
                </div>
            </div>
        </div>
    `;
}

// Render Image Card
function renderImageCard(image) {
    const shareUrl = getShareUrl(image.id, 'image');
    
    return `
        <div class="content-card" data-id="${image.id}" data-type="image">
            <div class="card-image">
                <img src="${escapeHtml(image.imageUrl)}" alt="${escapeHtml(image.title)}" loading="lazy">
                <button class="share-btn" data-share='${JSON.stringify({url: shareUrl, title: image.title, type: 'image', id: image.id})}'>
                    <i class="fas fa-share-alt"></i>
                </button>
            </div>
            <div class="card-content">
                <h3 class="card-title">${escapeHtml(image.title)}</h3>
                ${image.description ? `<p class="card-description">${escapeHtml(image.description)}</p>` : ''}
                <div class="card-meta">
                    <span><i class="far fa-calendar-alt"></i> ${formatDate(image.timestamp)}</span>
                    <span><i class="fas fa-eye"></i> ${image.views || 0} views</span>
                </div>
            </div>
        </div>
    `;
}

// Render Video Card
function renderVideoCard(video) {
    const embedUrl = getEmbedUrl(video.videoUrl);
    const shareUrl = getShareUrl(video.id, 'video');
    
    return `
        <div class="content-card" data-id="${video.id}" data-type="video">
            <div class="video-container">
                <iframe src="${embedUrl}" frameborder="0" allowfullscreen loading="lazy"></iframe>
                <button class="share-btn" data-share='${JSON.stringify({url: shareUrl, title: video.title, type: 'video', id: video.id})}'>
                    <i class="fas fa-share-alt"></i>
                </button>
            </div>
            <div class="card-content">
                <h3 class="card-title">${escapeHtml(video.title)}</h3>
                ${video.description ? `<p class="card-description">${escapeHtml(video.description)}</p>` : ''}
                <div class="card-meta">
                    <span><i class="far fa-calendar-alt"></i> ${formatDate(video.timestamp)}</span>
                    <span><i class="fas fa-eye"></i> ${video.views || 0} views</span>
                </div>
            </div>
        </div>
    `;
}

// Filter content based on search and category
function filterContent(items, type) {
    return items.filter(item => {
        const matchesSearch = searchQuery === '' || 
            item.title?.toLowerCase().includes(searchQuery) ||
            item.description?.toLowerCase().includes(searchQuery);
        
        const matchesCategory = currentFilter === 'all' || currentFilter === type;
        
        return matchesSearch && matchesCategory;
    });
}

// Render all content
function renderAllContent() {
    if (currentFilter === 'all' || currentFilter === 'poster') {
        const filteredPosters = filterContent(posters, 'poster');
        postersGrid.innerHTML = filteredPosters.map(p => renderPosterCard(p)).join('');
    } else {
        postersGrid.innerHTML = '';
    }
    
    if (currentFilter === 'all' || currentFilter === 'image') {
        const filteredImages = filterContent(images, 'image');
        imagesGrid.innerHTML = filteredImages.map(i => renderImageCard(i)).join('');
    } else {
        imagesGrid.innerHTML = '';
    }
    
    if (currentFilter === 'all' || currentFilter === 'video') {
        const filteredVideos = filterContent(videos, 'video');
        videosGrid.innerHTML = filteredVideos.map(v => renderVideoCard(v)).join('');
    } else {
        videosGrid.innerHTML = '';
    }
}

// Load content from Firebase
async function loadContent() {
    showSkeletons(postersGrid);
    showSkeletons(imagesGrid);
    showSkeletons(videosGrid);
    
    try {
        // Load posters
        const postersQuery = query(collection(db, COLLECTIONS.POSTERS), orderBy('timestamp', 'desc'));
        const postersSnap = await getDocs(postersQuery);
        posters = postersSnap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        
        // Load images
        const imagesQuery = query(collection(db, COLLECTIONS.IMAGES), orderBy('timestamp', 'desc'));
        const imagesSnap = await getDocs(imagesQuery);
        images = imagesSnap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        
        // Load videos
        const videosQuery = query(collection(db, COLLECTIONS.VIDEOS), orderBy('timestamp', 'desc'));
        const videosSnap = await getDocs(videosQuery);
        videos = videosSnap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        
        // Update stats
        document.getElementById('posters-count').textContent = posters.length;
        document.getElementById('images-count').textContent = images.length;
        document.getElementById('videos-count').textContent = videos.length;
        
        renderAllContent();
        
    } catch (error) {
        console.error('Error loading content:', error);
        showNotification('Failed to load content. Please refresh the page.', 'error');
    }
}

// Load Contact Section
function loadContact() {
    const contactHtml = `
        <div class="contact-grid">
            <div class="contact-info">
                <h3><i class="fas fa-map-marker-alt"></i> Visit Us</h3>
                <div class="contact-detail">
                    <i class="fas fa-location-dot"></i>
                    <span>Muzaffarpur, Atardah Road, Bihar 842002</span>
                </div>
                <div class="contact-detail">
                    <i class="fas fa-phone"></i>
                    <a href="tel:+919304328465">+91 93043 28465</a>
                </div>
                <div class="contact-detail">
                    <i class="fas fa-envelope"></i>
                    <a href="mailto:ethwemaketoppers@gmail.com">ethwemaketoppers@gmail.com</a>
                </div>
            </div>
            
            <div class="contact-info">
                <h3><i class="fas fa-share-alt"></i> Follow Us</h3>
                <div class="social-links">
                    <a href="https://www.instagram.com/education_toppers_hub" target="_blank" class="social-link">
                        <i class="fab fa-instagram"></i>
                    </a>
                    <a href="https://www.facebook.com/p/Education-Toppers-Hub-61555815687522" target="_blank" class="social-link">
                        <i class="fab fa-facebook"></i>
                    </a>
                    <a href="https://www.youtube.com/@ETH_learn" target="_blank" class="social-link">
                        <i class="fab fa-youtube"></i>
                    </a>
                    <a href="https://t.me/ETH_learn" target="_blank" class="social-link">
                        <i class="fab fa-telegram"></i>
                    </a>
                </div>
            </div>
            
            <div class="contact-info">
                <h3><i class="fas fa-clock"></i> Working Hours</h3>
                <div class="contact-detail">
                    <i class="fas fa-sun"></i>
                    <span>Monday - Friday: 9:00 AM - 6:00 PM</span>
                </div>
                <div class="contact-detail">
                    <i class="fas fa-moon"></i>
                    <span>Saturday: 10:00 AM - 4:00 PM</span>
                </div>
                <div class="contact-detail">
                    <i class="fas fa-calendar-week"></i>
                    <span>Sunday: Closed</span>
                </div>
            </div>
        </div>
    `;
    
    const contactSection = document.getElementById('contact');
    if (contactSection) contactSection.innerHTML = contactHtml;
}

// Load Footer
function loadFooter() {
    const footerHtml = `
        <div class="footer-content">
            <div class="footer-links">
                <a href="#home">Home</a>
                <a href="#posters">Posters</a>
                <a href="#images">Gallery</a>
                <a href="#videos">Videos</a>
                <a href="#contact">Contact</a>
                <a href="/privacy.html">Privacy Policy</a>
                <a href="/terms.html">Terms of Service</a>
            </div>
            <p>&copy; 2026 Education Toppers Hub. All rights reserved.</p>
            <p>Empowering learners, celebrating toppers</p>
        </div>
    `;
    
    const footer = document.getElementById('main-footer');
    if (footer) footer.innerHTML = footerHtml;
}

// Initialize Share Modal
function initShareModal() {
    const modalHtml = `
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-share-alt"></i> Share this content</h3>
                <button class="modal-close" id="modal-close">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="share-options" id="share-options"></div>
            <div class="share-link">
                <input type="text" id="share-link-input" readonly>
                <button class="btn btn-primary" id="copy-link-btn">
                    <i class="fas fa-copy"></i> Copy
                </button>
            </div>
        </div>
    `;
    
    const modal = document.getElementById('share-modal');
    if (modal) modal.innerHTML = modalHtml;
}

// Show share modal
function showShareModal(shareData) {
    const modal = document.getElementById('share-modal');
    const shareOptions = document.getElementById('share-options');
    const linkInput = document.getElementById('share-link-input');
    
    if (!modal || !shareOptions) return;
    
    const platforms = [
        { name: 'Facebook', icon: 'fab fa-facebook', color: '#1877f2' },
        { name: 'Twitter', icon: 'fab fa-twitter', color: '#1da1f2' },
        { name: 'WhatsApp', icon: 'fab fa-whatsapp', color: '#25d366' },
        { name: 'Telegram', icon: 'fab fa-telegram', color: '#0088cc' },
        { name: 'LinkedIn', icon: 'fab fa-linkedin', color: '#0077b5' },
        { name: 'Email', icon: 'fas fa-envelope', color: '#ea4335' }
    ];
    
    shareOptions.innerHTML = platforms.map(platform => `
        <div class="share-option" data-platform="${platform.name.toLowerCase()}">
            <i class="${platform.icon}" style="color: ${platform.color}"></i>
            <span>${platform.name}</span>
        </div>
    `).join('');
    
    linkInput.value = shareData.url;
    
    // Add share event listeners
    shareOptions.querySelectorAll('.share-option').forEach(option => {
        option.addEventListener('click', () => {
            const platform = option.dataset.platform;
            shareOnSocial(platform, shareData.url, shareData.title);
        });
    });
    
    document.getElementById('copy-link-btn').addEventListener('click', async () => {
        const copied = await copyToClipboard(shareData.url);
        if (copied) {
            showNotification('Link copied to clipboard!', 'success');
        }
    });
    
    modal.classList.add('active');
    
    // Close modal
    document.getElementById('modal-close').addEventListener('click', () => {
        modal.classList.remove('active');
    });
    
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.classList.remove('active');
        }
    });
}

// Event Listeners
function setupEventListeners() {
    // Search functionality
    if (searchInput) {
        const debouncedSearch = debounce((e) => {
            searchQuery = e.target.value.toLowerCase().trim();
            searchClear.style.display = searchQuery ? 'block' : 'none';
            renderAllContent();
        }, 300);
        
        searchInput.addEventListener('input', debouncedSearch);
    }
    
    if (searchClear) {
        searchClear.addEventListener('click', () => {
            searchInput.value = '';
            searchQuery = '';
            searchClear.style.display = 'none';
            renderAllContent();
        });
    }
    
    // Category filtering
    if (categories) {
        categories.addEventListener('click', (e) => {
            const btn = e.target.closest('.category-btn');
            if (!btn) return;
            
            document.querySelectorAll('.category-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            
            currentFilter = btn.dataset.category;
            renderAllContent();
        });
    }
    
    // Share button handling
    document.addEventListener('click', (e) => {
        const shareBtn = e.target.closest('.share-btn');
        if (shareBtn && shareBtn.dataset.share) {
            const shareData = JSON.parse(shareBtn.dataset.share);
            showShareModal(shareData);
        }
    });
    
    // Dark mode toggle
    const themeToggle = document.getElementById('theme-toggle');
    if (themeToggle) {
        themeToggle.addEventListener('click', () => {
            const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
            document.documentElement.setAttribute('data-theme', isDark ? 'light' : 'dark');
            localStorage.setItem('theme', isDark ? 'light' : 'dark');
            themeToggle.innerHTML = isDark ? '<i class="fas fa-moon"></i>' : '<i class="fas fa-sun"></i>';
        });
        
        // Load saved theme
        const savedTheme = localStorage.getItem('theme');
        if (savedTheme === 'dark') {
            document.documentElement.setAttribute('data-theme', 'dark');
            themeToggle.innerHTML = '<i class="fas fa-sun"></i>';
        }
    }
    
    // Mobile menu
    const mobileMenuBtn = document.getElementById('mobile-menu-btn');
    const navMenu = document.getElementById('nav-menu');
    
    if (mobileMenuBtn && navMenu) {
        mobileMenuBtn.addEventListener('click', () => {
            mobileMenuBtn.classList.toggle('active');
            navMenu.classList.toggle('active');
        });
    }
    
    // Back to top
    const backToTop = document.createElement('button');
    backToTop.className = 'back-to-top';
    backToTop.innerHTML = '<i class="fas fa-arrow-up"></i>';
    document.body.appendChild(backToTop);
    
    window.addEventListener('scroll', () => {
        if (window.scrollY > 300) {
            backToTop.classList.add('visible');
        } else {
            backToTop.classList.remove('visible');
        }
    });
    
    backToTop.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
}

// Initialize Lightbox
function initLightbox() {
    const lightbox = document.getElementById('lightbox');
    if (!lightbox) return;
    
    lightbox.innerHTML = `
        <button class="lightbox-close">&times;</button>
        <img class="lightbox-img" id="lightbox-img" alt="">
    `;
    
    document.addEventListener('click', (e) => {
        const img = e.target.closest('.card-image img');
        if (img) {
            const lightboxImg = document.getElementById('lightbox-img');
            lightboxImg.src = img.src;
            lightbox.classList.add('active');
        }
    });
    
    const closeBtn = lightbox.querySelector('.lightbox-close');
    if (closeBtn) {
        closeBtn.addEventListener('click', () => {
            lightbox.classList.remove('active');
        });
    }
    
    lightbox.addEventListener('click', (e) => {
        if (e.target === lightbox) {
            lightbox.classList.remove('active');
        }
    });
}

// Initialize
async function init() {
    await loadHeader();
    loadSearchFilter();
    loadStats();
    await loadContent();
    loadContact();
    loadFooter();
    initShareModal();
    initLightbox();
    setupEventListeners();
}

// Start the app
init();
