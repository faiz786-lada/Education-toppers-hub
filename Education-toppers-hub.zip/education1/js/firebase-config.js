// Firebase Configuration
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import { 
    getFirestore, 
    collection, 
    addDoc, 
    getDocs, 
    deleteDoc, 
    doc, 
    updateDoc,
    query, 
    orderBy, 
    limit,
    serverTimestamp,
    where,
    getDoc
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";
import { 
    getStorage, 
    ref, 
    uploadBytesResumable, 
    getDownloadURL, 
    deleteObject 
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-storage.js";
import { 
    getAuth, 
    signInWithEmailAndPassword, 
    signOut, 
    onAuthStateChanged 
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";

const firebaseConfig = {
    apiKey: "AIzaSyCzCp_EGGmSolCSy8iQNrQAE-vGO8vTKIo",
    authDomain: "education-toppers-hub-4d045.firebaseapp.com",
    projectId: "education-toppers-hub-4d045",
    storageBucket: "education-toppers-hub-4d045.firebasestorage.app",
    messagingSenderId: "1065320525597",
    appId: "1:1065320525597:web:ca166ff0d6e257492f3bf4",
    measurementId: "G-QTF6FHGEFZ"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const storage = getStorage(app);
const auth = getAuth(app);

// Collections
const COLLECTIONS = {
    POSTERS: 'posters',
    IMAGES: 'images',
    VIDEOS: 'videos',
    USERS: 'users',
    SETTINGS: 'settings',
    ACTIVITY: 'activity'
};

// Storage Paths
const STORAGE_PATHS = {
    POSTERS: 'posters/',
    IMAGES: 'images/',
    VIDEOS: 'videos/',
    LOGOS: 'logos/'
};

// Export
export {
    app,
    db,
    storage,
    auth,
    collection,
    addDoc,
    getDocs,
    deleteDoc,
    doc,
    updateDoc,
    query,
    orderBy,
    limit,
    where,
    serverTimestamp,
    getDoc,
    ref,
    uploadBytesResumable,
    getDownloadURL,
    deleteObject,
    signInWithEmailAndPassword,
    signOut,
    onAuthStateChanged,
    COLLECTIONS,
    STORAGE_PATHS
};
