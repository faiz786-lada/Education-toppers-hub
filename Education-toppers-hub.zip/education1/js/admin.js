import { 
    db, storage, auth,
    collection, addDoc, getDocs, deleteDoc, doc,
    query, orderBy, serverTimestamp,
    ref, uploadBytesResumable, getDownloadURL, deleteObject,
    signInWithEmailAndPassword, signOut, onAuthStateChanged,
    COLLECTIONS, STORAGE_PATHS
} from './firebase-config.js';
import { showNotification, validateFile, compressImage, escapeHtml } from './utils.js';

// Admin State
let isAdmin = false;
let currentUpload = null;

// DOM Elements
const loginForm = document.getElementById('login-form');
const adminPanel = document.getElementById('admin-panel');
const loginSection = document.getElementById('login-section');

// Check Auth State
onAuthStateChanged(auth, (user) => {
    if (user) {
        isAdmin = true;
        if (loginSection) loginSection.style.display = 'none';
        if (adminPanel) adminPanel.style.display = 'block';
        loadAdminData();
        showNotification('Welcome to Admin Panel!', 'success');
    } else {
        isAdmin = false;
        if (loginSection) loginSection.style.display = 'flex';
        if (adminPanel) adminPanel.style.display = 'none';
    }
});

// Admin Login
if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const email = document.getElementById('admin-email').value;
        const password = document.getElementById('admin-password').value;
        
        try {
            await signInWithEmailAndPassword(auth, email, password);
        } catch (error) {
            showNotification('Login failed: ' + error.message, 'error');
        }
    });
}

// Admin Logout
document.getElementById('logout-btn')?.addEventListener('click', async () => {
    await signOut(auth);
    showNotification('Logged out successfully', 'success');
});

// Upload file with progress
async function uploadFile(file, path, onProgress) {
    const storageRef = ref(storage, path);
    const uploadTask = uploadBytesResumable(storageRef, file);
    
    return new Promise((resolve, reject) => {
        uploadTask.on('state_changed',
            (snapshot) => {
                const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
                if (onProgress) onProgress(progress);
            },
            (error) => reject(error),
            async () => {
                const downloadURL = await getDownloadURL(uploadTask.snapshot.ref);
                resolve(downloadURL);
            }
        );
    });
}

// Upload Poster
document.getElementById('poster-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const title = document.getElementById('poster-title').value;
    const description = document.getElementById('poster-description').value;
    const file = document.getElementById('poster-file').files[0];
    
    if (!file) {
        showNotification('Please select an image', 'error');
        return;
    }
    
    const validation = validateFile(file);
    if (!validation.valid) {
        showNotification(validation.error, 'error');
        return;
    }
    
    const progressBar = document.getElementById('poster-progress');
    const progressFill = document.getElementById('poster-progress-fill');
    const progressText = document.getElementById('poster-progress-text');
    
    progressBar.style.display = 'block';
    
    try {
        // Compress image
        const compressedFile = await compressImage(file);
        const fileName = `poster_${Date.now()}_${file.name}`;
        const filePath = `${STORAGE_PATHS.POSTERS}${fileName}`;
        
        const imageUrl = await uploadFile(compressedFile, filePath, (progress) => {
            progressFill.style.width = `${progress}%`;
            progressText.textContent = `${Math.round(progress)}%`;
        });
        
        await addDoc(collection(db, COLLECTIONS.POSTERS), {
            title,
            description,
            imageUrl,
            timestamp: serverTimestamp(),
            views: 0
        });
        
        showNotification('Poster uploaded successfully!', 'success');
        e.target.reset();
        progressBar.style.display = 'none';
        
    } catch (error) {
        showNotification('Upload failed: ' + error.message, 'error');
        progressBar.style.display = 'none';
    }
});

// Upload Image
document.getElementById('image-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const title = document.getElementById('image-title').value;
    const description = document.getElementById('image-description').value;
    const file = document.getElementById('image-file').files[0];
    
    if (!file) {
        showNotification('Please select an image', 'error');
        return;
    }
    
    const validation = validateFile(file);
    if (!validation.valid) {
        showNotification(validation.error, 'error');
        return;
    }
    
    const progressBar = document.getElementById('image-progress');
    const progressFill = document.getElementById('image-progress-fill');
    const progressText = document.getElementById('image-progress-text');
    
    progressBar.style.display = 'block';
    
    try {
        const compressedFile = await compressImage(file);
        const fileName = `image_${Date.now()}_${file.name}`;
        const filePath = `${STORAGE_PATHS.IMAGES}${fileName}`;
        
        const imageUrl = await uploadFile(compressedFile, filePath, (progress) => {
            progressFill.style.width = `${progress}%`;
            progressText.textContent = `${Math.round(progress)}%`;
        });
        
        await addDoc(collection(db, COLLECTIONS.IMAGES), {
            title,
            description,
            imageUrl,
            timestamp: serverTimestamp(),
            views: 0
        });
        
        showNotification('Image uploaded successfully!', 'success');
        e.target.reset();
        progressBar.style.display = 'none';
        
    } catch (error) {
        showNotification('Upload failed: ' + error.message, 'error');
        progressBar.style.display = 'none';
    }
});

// Upload Video (URL based)
document.getElementById('video-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const title = document.getElementById('video-title').value;
    const description = document.getElementById('video-description').value;
    const videoUrl = document.getElementById('video-url').value;
    
    if (!videoUrl) {
        showNotification('Please enter video URL', 'error');
        return;
    }
    
    try {
        await addDoc(collection(db, COLLECTIONS.VIDEOS), {
            title,
            description,
            videoUrl,
            timestamp: serverTimestamp(),
            views: 0
        });
        
        showNotification('Video added successfully!', 'success');
        e.target.reset();
        
    } catch (error) {
        showNotification('Failed to add video: ' + error.message, 'error');
    }
});

// Load Admin Data
async function loadAdminData() {
    await loadContentList();
    loadStats();
}

// Load content list for management
async function loadContentList() {
    const postersList = document.getElementById('posters-list');
    const imagesList = document.getElementById('images-list');
    const videosList = document.getElementById('videos-list');
    
    if (postersList) {
        const postersSnap = await getDocs(query(collection(db, COLLECTIONS.POSTERS), orderBy('timestamp', 'desc')));
        postersList.innerHTML = postersSnap.docs.map(doc => `
            <div class="admin-item">
                <img src="${escapeHtml(doc.data().imageUrl)}" alt="${escapeHtml(doc.data().title)}">
                <div class="admin-item-info">
                    <h4>${escapeHtml(doc.data().title)}</h4>
                    <button onclick="deleteContent('poster', '${doc.id}')" class="btn-danger">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </div>
            </div>
        `).join('');
    }
    
    if (imagesList) {
        const imagesSnap = await getDocs(query(collection(db, COLLECTIONS.IMAGES), orderBy('timestamp', 'desc')));
        imagesList.innerHTML = imagesSnap.docs.map(doc => `
            <div class="admin-item">
                <img src="${escapeHtml(doc.data().imageUrl)}" alt="${escapeHtml(doc.data().title)}">
                <div class="admin-item-info">
                    <h4>${escapeHtml(doc.data().title)}</h4>
                    <button onclick="deleteContent('image', '${doc.id}')" class="btn-danger">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </div>
            </div>
        `).join('');
    }
    
    if (videosList) {
        const videosSnap = await getDocs(query(collection(db, COLLECTIONS.VIDEOS), orderBy('timestamp', 'desc')));
        videosList.innerHTML = videosSnap.docs.map(doc => `
            <div class="admin-item">
                <div class="video-thumb">
                    <i class="fas fa-video"></i>
                </div>
                <div class="admin-item-info">
                    <h4>${escapeHtml(doc.data().title)}</h4>
                    <button onclick="deleteContent('video', '${doc.id}')" class="btn-danger">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </div>
            </div>
        `).join('');
    }
}

// Delete content
window.deleteContent = async (type, id) => {
    if (!confirm(`Are you sure you want to delete this ${type}?`)) return;
    
    try {
        // Get the document to find the file URL
        const docRef = doc(db, COLLECTIONS[type.toUpperCase() + 'S'], id);
        const docSnap = await getDoc(docRef);
        
        if (docSnap.exists() && docSnap.data().imageUrl) {
            // Delete from storage if it's an image
            const fileRef = ref(storage, docSnap.data().imageUrl);
            await deleteObject(fileRef).catch(() => {});
        }
        
        await deleteDoc(docRef);
        showNotification(`${type} deleted successfully`, 'success');
        loadContentList();
        loadStats();
        
    } catch (error) {
        showNotification('Delete failed: ' + error.message, 'error');
    }
};

// Load stats
async function loadStats() {
    const postersSnap = await getDocs(collection(db, COLLECTIONS.POSTERS));
    const imagesSnap = await getDocs(collection(db, COLLECTIONS.IMAGES));
    const videosSnap = await getDocs(collection(db, COLLECTIONS.VIDEOS));
    
    document.getElementById('stat-posters').textContent = postersSnap.size;
    document.getElementById('stat-images').textContent = imagesSnap.size;
    document.getElementById('stat-videos').textContent = videosSnap.size;
    document.getElementById('stat-total').textContent = postersSnap.size + imagesSnap.size + videosSnap.size;
}

// File input preview
function setupFilePreview(inputId, previewId) {
    const input = document.getElementById(inputId);
    const preview = document.getElementById(previewId);
    
    if (input && preview) {
        input.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = (e) => {
                    preview.innerHTML = `<img src="${e.target.result}" alt="Preview">`;
                };
                reader.readAsDataURL(file);
            } else {
                preview.innerHTML = '';
            }
        });
    }
}

// Setup all file previews
setupFilePreview('poster-file', 'poster-preview');
setupFilePreview('image-file', 'image-preview');

// Video URL preview
const videoUrlInput = document.getElementById('video-url');
const videoPreview = document.getElementById('video-preview');

if (videoUrlInput && videoPreview) {
    videoUrlInput.addEventListener('input', () => {
        const url = videoUrlInput.value;
        if (url.includes('youtube.com') || url.includes('youtu.be')) {
            const videoId = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([^&]+)/)?.[1];
            if (videoId) {
                videoPreview.innerHTML = `
                    <iframe src="https://www.youtube.com/embed/${videoId}" frameborder="0" allowfullscreen></iframe>
                `;
                return;
            }
        }
        videoPreview.innerHTML = '';
    });
}
